#include <iostream>
using namespace std;


// forward declaration of template class List

template<class T>
class List;

template<class T>
class Node
{
private:
	friend List<T>;
	T info;
	Node<T>* next;
public:
										// Methods�
	//Default Constructor:
	Node() 
	{
		info = 0;
		next = NULL;
	}
	//Parameterized Constructor:
	Node(T val) 
	{
		this->info = val;
		this->next = NULL;
	}
};

template<class T>
class List
{
private:
	Node<T>* head;
public:
	List()
	{
		head = NULL;
	}
	~List() 
	{
		Node<T>*toDelete = head;
		while (head) {
			//cout << "DELETING" << endl;
			toDelete = head;
			head = head->next;
			delete toDelete;

			//				OR
			//deleteAtHead();
		}
	
	}
	//Copy Constructor
	List(const List& lhs) {
		if (!lhs.head) {
			head = NULL;
			return;
		}
		else {
			Node<T>*temp = lhs.head;
			while (temp) {
				//Creating new node to hold data
				Node<T>*NewNode = new Node<T>(temp->info);
				if (this->head == NULL) {
					head = NewNode;
				}
				else {
					//inserting that node into newly created link list 
					this->insertAtTail(NewNode->info);
				}
				temp = temp->next;
			}
		}
	}



	void insertAtHead(T value) 
	{

		Node<T>*NewNode = new Node<T>(value);
		if (head == NULL) {
			head = NewNode;
			return;
		}
		else {

			NewNode->next = head;
			head = NewNode;
			return;
		}

		/*
		else {
			Node<T>*temp = head;
			while (temp->next!=NULL)
			{
				temp = temp->next;
			}
			temp->next = NewNode;
		}*/

	}
	void insertAtHead(Node<T>* newNode) 
	{
		if (head == NULL) {
			head = newNode;
			return;
		}
		else {
			newNode->next = head;
			head = newNode;
		}
	}

	void insertAtTail(T value) 
	{
		Node<T>*NewNode = new Node<T>(value);
		if (head == NULL) {
			head = NewNode;
			return;
		}
		else  if (head != NULL) {
			Node<T>*temp = head;
			//traverse till end
			while (temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = NewNode;
		}
	}
	void insertAtTail(Node<T>* newNode) 
	{
		if (head == NULL) {
			head = newNode;
			return;
		}
		else  if (head != NULL) {
			Node<T>*temp = head;
			//traverse till end
			while (temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = newNode;
			//newNode->next = nullptr;
		}
	}
	bool deleteAtHead() 
	{
		if (head == NULL) {
			return false;
		}
		Node<T>*toDelete = head;
		head = head->next;
		delete toDelete;
		return true;
	}
	bool deleteAtTail() 
	{
		if (head==NULL)
		{
			return false;
		}
		else if (head != NULL) {
			if (head->next == NULL) {
				delete head;
				head = NULL;
				return true;
			}
			Node<T>*prev = nullptr;
			Node<T>*toDelete = head;
			while (toDelete->next)
			{
				prev = toDelete;
				toDelete = toDelete->next;
			}
			prev->next = nullptr;
			delete toDelete;
			return true;
		}
	}

	void printList() 
	{
		if (head == NULL) {
			cout << "List is Empty!" << endl;
		}
		//else if (head != NULL) 
		else{
			Node<T>*temp = head;
			cout << "Elements in List are: " << endl;
			while (temp) {

				cout << temp->info << " ";
				temp = temp->next;
			}

		}
	}
	Node<T>* search(T x) 
	{
		if (head = NULL) {
			return nullptr;
		}
		else if (head != NULL) {
			Node<T>*temp = head;
			while (temp)
			{
				if (temp->info==x) {
					Node<T>*pointer = temp;
					return pointer;
				}
				temp = temp->next;
			}
		}
		return nullptr;
	}

	bool insertAfter(T key, T value) 
	{
		if (head == NULL) {
			Node<T>*NewNode = new Node<T>(value);
			head = NewNode;
			return true;
		}
		else if (head != NULL) {
			Node<T>*temp = head;
			while (temp) {
				if (temp->info == key)
				{
					Node<T>*NewNode = new Node<T>(value);
					NewNode->next = temp->next;
					temp->next = NewNode;
					return true;
				}
				temp = temp->next;
			}
		}
	}

	bool insertBefore(T key, T value) 
	{
		if (head == NULL) {
			Node<T>*NewNode = new Node<T>(value);
			head = NewNode;
			return true;
		}
		else if (head != NULL) {
			Node<T>*prev = nullptr;
			Node<T>*temp = head;
			/*if (temp->next==NULL) {
				if (temp->info == key) {
				Node<T>*NewNode = new Node<T>(value);
				NewNode->next = temp;
				temp = NewNode;
				return true;
				}
			}*/
			while (temp->next) {
				//IF key is found at first node
				if (temp->info == key && temp == head) {
					Node<T>*NewNode = new Node<T>(value);
					NewNode->next = temp;
					head = NewNode;
					return true;
				}
				if (temp->info == key)
				{
					Node<T>*NewNode = new Node<T>(value);
					NewNode->next = prev->next;
					prev->next = NewNode;
					return true;
				}
				prev = temp;
				temp = temp->next;
			}
		}

	}

	int getLength() 
	{
		if (head == NULL) {
			return 0;
		}
		else if (head != NULL) {
			int count = 0;
			Node<T>*temp = head;
			while (temp)
			{
				count++;
				temp = temp->next;
			}
			return count;
		}
	}

	bool deleteBefore(T key) 
	{
		if (head==NULL)
		{
			return false;
		}
		else if (head != NULL) {
			Node<T>*prev = nullptr;
			Node<T>*toDelete = head;
			while (toDelete->next)
			{
				if (toDelete->info == key) {
					prev->next = toDelete->next;
					delete toDelete;
					return true;
				}
				prev = toDelete;
				toDelete = toDelete->next;
			}
		}
		return false;
	}

	bool deleteAfter(T key) 
	{
		if (head == NULL)
		{
			return false;
		}
		else if (head != NULL) {
		/*	Node<T>*prev = nullptr;*/
			Node<T>*temp = head;
			while (temp->next)
			{
				if (temp->info == key) {
					Node<T>*toDelete = temp->next;
					temp->next = toDelete->next;
					delete toDelete;
					return true;
				}
				temp = temp->next;
			}
		}
		return false;
	}

	void compress() {
		if (!head) {
			cout << "LIST IS EMPTY!" << endl;
			return;
		}
		else {
			cout << "LIST 2 After Compressing: " << endl;
			Node<T>*temp = head;
			Node<T>*next;
			while (temp->next) 
			{	//Chekcing data of next node if same or not
				if (temp->info==temp->next->info) 
				{	//If data is same then skipping the pointer(next) to next pointer after same data node is found then deleting it
					next = temp->next->next;
					delete temp->next;
					temp->next = next;
				}
				else {//if data of Nodes isn't same then just skipping to next node 
					temp = temp->next;
				}

			}

		}


	}

};
int main()
{

	List<int> list;
	// Inserting nodes
	list.insertAtHead(4);
	list.insertAtHead(3);
	list.insertAtHead(2);
	list.insertAtHead(1);
	list.insertAtTail(5);
	list.insertAtTail(6);
	list.insertAtTail(7);
	list.insertAtTail(8);

	list.printList();

	Node<int>*NewNode = new Node<int>(0);
	list.insertAtHead(NewNode);
	cout << endl;
	list.printList();

	Node<int>*NewNode1 = new Node<int>(9);
	list.insertAtTail(NewNode1);
	cout << endl;
	list.printList();

	bool isDeleted = list.deleteAtHead();
	if (isDeleted) {
		cout << "After Deleting Head, LinkList is: " << endl;
		list.printList();
	}
	if (!isDeleted) {
		cout << "List is Empty!" << endl;
	}
	

	cout << endl;
	bool isDeleted1 = list.deleteAtTail();
	if (isDeleted1) {
		cout << "After Deleting Head, LinkList is: " << endl;
		list.printList();
	}
	if (!isDeleted1) {
		cout << "List is Empty!" << endl;
	}
	
	list.insertAfter(5, 15);
	cout << endl;
	list.printList();

	list.insertAfter(9, 10);
	cout << endl;
	list.printList();


	list.insertBefore(5, 51);
	cout << endl;
	list.printList();

	list.insertBefore(9, 91);
	cout << endl;
	list.printList();


	list.insertBefore(0, -1);
	cout << endl;
	list.printList();

	
	list.deleteAtTail();
	cout << endl;
	list.printList();

	list.deleteAtHead();
	cout << endl;
	list.printList();


	List<int> list2;
	// Inserting nodes
	list2.insertAtTail(1);
	
	list2.insertAtTail(2);
	list2.insertAtTail(2);
	list2.insertAtTail(3);
	list2.insertAtTail(3);
	list2.insertAtTail(4);
	list2.insertAtTail(4);
	list2.insertAtTail(4);
	list2.insertAtTail(5);
	list2.insertAtTail(5);
	list2.insertAtTail(5);
	list2.insertAtTail(6);
	//Compressing List
	list2.compress();
	
	list2.printList();

	List<int> list3(list);
	cout << "LIST CREATED FROm COPY CONSTRUCTOR:-" << endl;
	list3.printList();

	return 0;

}
